import { useEffect, useRef, useState } from "react";
import { useMotionPreference } from "@/hooks/use-motion-preference";

const GLYPHS = "01アイウエオカキクケコサシスセソタチツテナニヌabcdef{}<>/$#*+=".split("");

/** Faint green code-rain, only visible in dark (hacker) mode. */
export function MatrixRain() {
  const ref = useRef<HTMLCanvasElement>(null);
  const [isDark, setIsDark] = useState(false);
  const { reduced } = useMotionPreference();

  useEffect(() => {
    const el = document.documentElement;
    const sync = () => setIsDark(el.classList.contains("dark"));
    sync();
    const obs = new MutationObserver(sync);
    obs.observe(el, { attributes: true, attributeFilter: ["class"] });
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    if (!isDark) return;
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const font = 16;
    let cols = 0;
    let drops: number[] = [];
    let dpr = 1;

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.floor(window.innerWidth * dpr);
      canvas.height = Math.floor(window.innerHeight * dpr);
      canvas.style.width = "100%";
      canvas.style.height = "100%";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      cols = Math.ceil(window.innerWidth / font);
      drops = Array.from({ length: cols }, () => Math.random() * (window.innerHeight / font));
    };
    resize();
    window.addEventListener("resize", resize, { passive: true });

    let raf = 0;
    let last = 0;
    const step = (t: number) => {
      raf = requestAnimationFrame(step);
      const interval = reduced ? 220 : 70;
      if (t - last < interval) return;
      last = t;

      ctx.fillStyle = "rgba(0,0,0,0.14)";
      ctx.fillRect(0, 0, window.innerWidth, window.innerHeight);
      ctx.font = `${font}px ui-monospace, monospace`;

      for (let i = 0; i < cols; i++) {
        const x = i * font;
        const y = (drops[i] ?? 0) * font;
        const g = GLYPHS[(Math.random() * GLYPHS.length) | 0] ?? "0";
        ctx.fillStyle = "rgba(120, 255, 170, 0.28)";
        ctx.fillText(g, x, y);
        ctx.fillStyle = "rgba(190, 255, 215, 0.5)";
        ctx.fillText(g, x, y - font);

        if (y > window.innerHeight && Math.random() > 0.975) drops[i] = 0;
        else drops[i] = (drops[i] ?? 0) + 1;
      }

    };
    raf = requestAnimationFrame(step);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [isDark, reduced]);

  if (!isDark) return null;

  return (
    <canvas
      ref={ref}
      aria-hidden
      className="pointer-events-none fixed inset-0 z-0 opacity-25"
      style={{ mixBlendMode: "screen" }}
    />
  );
}
