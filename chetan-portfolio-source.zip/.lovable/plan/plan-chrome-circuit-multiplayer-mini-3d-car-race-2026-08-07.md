# Plan: Chrome Circuit — Multiplayer Mini 3D Car Race

## What we're building
A new arcade game route (`/race`) where players use the existing arcade player ID to create or join private race rooms, race on a stylised low-poly 3D track, and see a live leaderboard. Reuses the current "Ivory Prism" visual system and Firebase/Firestore backend.

## User flow
1. **Identity** — player enters their existing arcade player ID or creates a new one (reuse `arcade.ts` player logic).
2. **Lobby** — choose "Create Room" (gets a 4-letter room code) or "Join Room" (enter a friend's code).
3. **Room** — host sees connected players and clicks "Start Race". Others wait.
4. **Race** — simple 3D track (Three.js + `@react-three/fiber`). Tap/press to accelerate, steer with arrow keys / A-D / tilt on mobile. Lap timer shown.
5. **Finish** — positions + best lap saved to Firestore. Room leaderboard shown. Option to play again.

## Technical scope
- **Frontend**: new `src/routes/race.tsx`, `src/components/site/race-game.tsx`, `src/components/site/race-lobby.tsx`.
- **3D engine**: `@react-three/fiber`, `@react-three/drei`, `three`. Lightweight scene: plane track, low-poly car, checkpoints, finish line.
- **Multiplayer sync**: Firestore document per room (`raceRooms/{roomCode}`). Each client writes player state (`x, z, rotation, speed, lap, finishedAt`) every ~100ms. Host authoritative for race phase/countdown.
- **Leaderboard**: per-room leaderboard stored in the room doc; also global "Race" leaderboard collection for all-time best lap times.
- **Admin**: add a "Race Rooms" tab in admin arcade control to view active rooms, delete stale rooms, and toggle the game on/off.

## Out of scope for this pass
- True physics engine (Cannon/rapier) — use simple arcade steering.
- Voice chat or real-time chat.
- More than one track or car customisation.

## Files to create / modify
- `src/routes/race.tsx` — route + SEO head.
- `src/components/site/race-game.tsx` — 3D scene + car controller.
- `src/components/site/race-lobby.tsx` — create/join/waiting UI.
- `src/lib/race.ts` — Firestore room/player helpers.
- `src/components/site/arcade.tsx` — add "Chrome Circuit" entry card.
- `src/components/site/arcade-control.tsx` — add Race Rooms moderation tab.
- `src/routeTree.gen.ts` — generated after adding route (do not edit by hand).

## Verification
- Build passes (`bun run build`).
- `/race` loads, create room works, second tab joins via code, race starts, positions sync, leaderboard updates.
